-- *************************************************************************
-- >>>>>>>>>>>>>>>>>>>>>> create database <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
-- *************************************************************************

create database lit_test;

-- *************************************************************************
-- >>>>>>>>>>>>>>>>>>>>>> create user <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
-- *************************************************************************

create user lit_test@'%' identified by 'litopr';
grant all privileges on lit_test.* to lit_test@'%' with grant option;
ALTER USER 'lit_test'@'%' IDENTIFIED WITH mysql_native_password BY 'litopr';
flush privileges;

-- *************************************************************************
-- >>>>>>>>>>>>>>>>>>>>>> create tables <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
-- *************************************************************************

use lit_test;

create Table T_BOOK_DML
(
	BK_ID int(11)  NOT NULL AUTO_INCREMENT COMMENT 'book id',
	BK_NAME varchar(32) NOT NUll COMMENT 'book name',
	AUTHOR varchar(32) NOT NULL COMMENT 'author',
	STATUS char(1) NOT NULL COMMENT 'status',
	RATING int(1) COMMENT 'rating',
	IS_SYS char(1) NOT NULL COMMENT 'book provider',
	REMARK varchar(128) NOT NULL COMMENT 'comment',
	PRIMARY KEY (BK_ID)
);


-- *************************************************************************
-- >>>>>>>>>>>>>>>>>>>>>> insert data <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
-- *************************************************************************


INSERT INTO `t_book_dml` VALUES (1, 'Harry Petter', 'J.K.Rolling', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (2, 'TestBook1', 'TestAuthor', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (3, 'TestBook2', 'TestAuthor', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (4, 'TestBook3', 'TestAuthor', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (5, 'TestBook4', 'TestAuthor', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (6, 'TestBook5', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (7, 'TestBook6', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (8, 'TestBook7', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (9, 'TestBook8', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (10, 'TestBook9', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (11, 'TestBook10', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (12, 'TestBook11', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (13, 'TestBook12', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (14, 'TestBook13', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (15, 'TestBook14', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (16, 'TestBook15', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (17, 'TestBook16', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (18, 'TestBook17', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (19, 'TestBook18', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (20, 'TestBook19', 'TestAuthor', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (21, 'TestBook20', 'TestAuthor20', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (22, 'TestBook21', 'TestAuthor21', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (23, 'TestBook22', 'TestAuthor22', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (24, 'TestBook23', 'TestAuthor23', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (25, 'TestBook24', 'TestAuthor24', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (26, 'TestBook25', 'TestAuthor25', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (27, 'TestBook26', 'TestAuthor26', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (28, 'TestBook27', 'TestAuthor27', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (29, 'TestBook28', 'TestAuthor28', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (30, 'TestBook29', 'TestAuthor29', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (31, 'TestBook30', 'TestAuthor30', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (32, 'TestBook31', 'TestAuthor31', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (33, 'TestBook32', 'TestAuthor32', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (34, 'TestBook33', 'TestAuthor33', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (35, 'TestBook34', 'TestAuthor34', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (36, 'TestBook35', 'TestAuthor35', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (37, 'TestBook36', 'TestAuthor36', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (38, 'TestBook37', 'TestAuthor37', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (39, 'TestBook38', 'TestAuthor38', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (40, 'TestBook39', 'TestAuthor39', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (41, 'TestBook40', 'TestAuthor40', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (42, 'TestBook41', 'TestAuthor41', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (43, 'TestBook42', 'TestAuthor42', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (44, 'TestBook43', 'TestAuthor43', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (45, 'TestBook44', 'TestAuthor44', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (46, 'TestBook45', 'TestAuthor45', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (47, 'TestBook46', 'TestAuthor46', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (48, 'TestBook47', 'TestAuthor47', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (49, 'TestBook48', 'TestAuthor48', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (50, 'TestBook49', 'TestAuthor49', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (51, 'TestBook50', 'TestAuthor50', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (52, 'TestBook51', 'TestAuthor51', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (53, 'TestBook52', 'TestAuthor52', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (54, 'TestBook53', 'TestAuthor53', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (55, 'TestBook54', 'TestAuthor54', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (56, 'TestBook55', 'TestAuthor55', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (57, 'TestBook56', 'TestAuthor56', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (58, 'TestBook57', 'TestAuthor57', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (59, 'TestBook58', 'TestAuthor58', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (60, 'TestBook59', 'TestAuthor59', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (61, 'TestBook60', 'TestAuthor60', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (62, 'TestBook61', 'TestAuthor61', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (63, 'TestBook62', 'TestAuthor62', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (64, 'TestBook63', 'TestAuthor63', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (65, 'TestBook64', 'TestAuthor64', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (66, 'TestBook65', 'TestAuthor65', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (67, 'TestBook66', 'TestAuthor66', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (68, 'TestBook67', 'TestAuthor67', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (69, 'TestBook68', 'TestAuthor68', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (70, 'TestBook69', 'TestAuthor69', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (71, 'TestBook70', 'TestAuthor70', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (72, 'TestBook71', 'TestAuthor71', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (73, 'TestBook72', 'TestAuthor72', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (74, 'TestBook73', 'TestAuthor73', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (75, 'TestBook74', 'TestAuthor74', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (76, 'TestBook75', 'TestAuthor75', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (77, 'TestBook76', 'TestAuthor76', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (78, 'TestBook77', 'TestAuthor77', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (79, 'TestBook78', 'TestAuthor78', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (80, 'TestBook79', 'TestAuthor79', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (81, 'TestBook80', 'TestAuthor80', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (82, 'TestBook81', 'TestAuthor81', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (83, 'TestBook82', 'TestAuthor82', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (84, 'TestBook83', 'TestAuthor83', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (85, 'TestBook84', 'TestAuthor84', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (86, 'TestBook85', 'TestAuthor85', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (87, 'TestBook86', 'TestAuthor86', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (88, 'TestBook87', 'TestAuthor87', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (89, 'TestBook88', 'TestAuthor88', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (90, 'TestBook89', 'TestAuthor89', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (91, 'TestBook90', 'TestAuthor90', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (92, 'TestBook91', 'TestAuthor91', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (93, 'TestBook92', 'TestAuthor92', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (94, 'TestBook93', 'TestAuthor93', 'B', 5, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (95, 'TestBook94', 'TestAuthor94', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (96, 'TestBook95', 'TestAuthor95', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (97, 'TestBook96', 'TestAuthor96', 'B', 2, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (98, 'TestBook97', 'TestAuthor97', 'B', 3, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (99, 'TestBook98', 'TestAuthor98', 'B', 1, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (100, 'TestBook99', 'TestAuthor99', 'B', 4, 'S', 'asdasdafasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfasdfassd');
INSERT INTO `t_book_dml` VALUES (101, '1984', 'George Orwell', 'B', 3, 'U', 'This is a nice book!');