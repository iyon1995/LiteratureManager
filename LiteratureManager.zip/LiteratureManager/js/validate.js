/**
 * Created by sr199 on 12/7/2018.
 */

function validate(){
    var  title = document.getElementById("title").value;
    var  author = document.getElementById("author").value;
    var  status = document.getElementById("status").value;
    var  rating = document.getElementById("rating").value;
    var  comment = document.getElementById("comment").value;

    //var regx = /(?!^\d+$)(?!^[a-zA-Z]+$)[0-9a-zA-Z]{4,23}/;
    var regx = /<[^<>]+>/g;

    if(title == "" ||author == "" ||status == "" ||rating == "" ||comment == ""){
        alert("Error1: Book information is not complete!!!");
        return false;
    }else if(regx.test(title)){
        alert("Error2: Book title can contain number and letter only!!!");
        return false;
    }else if(regx.test(author)){
        alert("Error2: Book author can contain number and letter only!!!");
        return false;
    }else if(regx.test(comment)){
        alert("Error2: Book comment can contain number and letter only!!!");
        return false;
    }else if(title.length > 30){
        alert("Error3: Book title can contain max 30 char only!!!");
        return false;
    }else if(author.length > 30){
        alert("Error3: Book author can contain max 30 char only!!!");
        return false;
    }else if(comment.length > 120){
        alert("Error3: Book comment can contain max 30 char only!!!");
        return false;
    }else{
        return true;
    }


}