<?php
/**
 * Created by PhpStorm.
 * Author: rui.song
 * Date: 12/7/2018
 * Time: 11:01 AM
 * Version:
 * Description:
 */

require_once '../Model/Book.class.php';
require_once '../Service/BookService.class.php';

/**
 * get user input of a new book
 */
$book = new Book("temp");
if(!empty($_POST['bk_title'])){
    $book -> setBookName($_POST['bk_title']);
}

if(!empty($_POST['bk_author'])){
    $book -> setAuthor($_POST['bk_author']);
}

if(!empty($_POST['bk_status'])){
    $book -> setStatus($_POST['bk_status']);
}

if(!empty($_POST['bk_rating'])){
    $book -> setRating($_POST['bk_rating']);
}

if(!empty($_POST['bk_comment'])){
    $book -> setComment($_POST['bk_comment']);
}

$book -> setIsSys("U");

$bookService = new BookService();
if($bookService -> addBook($book) != 1){
    header("Location: ../pages/AddBook.html?errno=3");
    exit();
}else{
    header("Location: ../pages/BookList.php");
    exit();
}



?>