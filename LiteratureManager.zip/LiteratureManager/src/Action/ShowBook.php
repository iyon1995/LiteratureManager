<?php
/**
 * Created by PhpStorm.
 * Author: rui.song
 * Date: 12/6/2018
 * Time: 8:33 PM
 * Version:
 * Description:
 */

require_once '../Model/Book.class.php';
require_once '../Service/BookService.class.php';
require_once '../Model/Pages.class.php';


/**
 * show books and generate html code
 */
function showBooks(){
    $bookService = new BookService();
    if(!empty($_GET['pageNow'])){
        $pageNow = $_GET['pageNow'];
    }else{
        $pageNow = 1;
    }
    $pageSize = 3;
    $rowCount = $bookService -> getPages();
    $pages = new Pages($rowCount,$pageSize,$pageNow,"BookList.php");

    $books = $bookService -> getBooks($pages -> getStartNo(),$pages -> getPageSize());

    foreach ($books as $key => $val){
        echo "<div class='book-info'>";
        echo "<table>";
        echo "<tr>";
        echo "<th>Title:</th><td colspan=\"4\" class='long-td'>";
        echo $val -> getBookName();
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th>Author:</th><td>";
        echo $val -> getAuthor();
        echo "</td>";
        echo "<th>Status:</th><td>";
        $status = $val -> getStatus();
        if($status = "b"){
            echo "buy";
        }else if($status = "r"){
            echo "read";
        }else if($status = "f"){
            echo "finished";
        }
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th>Rating:</th><td colspan=\"4\" class='long-td'>";
        for ($i = 0;$i < $val -> getRating();$i++){
            echo "&blacklozenge;&nbsp;";
        }
        echo "</td>";
        echo "</tr>";
        echo "<tr>";
        echo "<th>Comment:</th><td colspan=\"4\" class='long-td'>";
        echo $val -> getComment();
        echo "</td>";
        echo "</tr>";
        echo "</table>";
        echo "</div>";

    }

}

/**
 * show pages
 */
function showPages(){
    $bookService = new BookService();
    $rowCount = 0;
    if(!empty($_GET['pageNow'])){
        $pageNow = $_GET['pageNow'];
    }else{
        $pageNow = 1;
    }
    $pageSize = 3;
    $rowCount = $bookService -> getPages();
    $pages = new Pages($rowCount,$pageSize,$pageNow,"BookList.php");
    $pages -> paging();
}


?>