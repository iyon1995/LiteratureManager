<?php
/**
 * Created by PhpStorm.
 * Author: rui.song
 * Date: 12/6/2018
 * Time: 8:33 PM
 * Version:
 * Description:
 */
require_once '../Action/ShowBook.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html;chaeset=utf-8" />
    <link rel="stylesheet" type="text/css" href="../../css/general.css">
    <link rel="stylesheet" type="text/css" href="../../css/books.css">
    <title>BookList</title>
</head>
<body onload="showPageNow()">
<script type="text/javascript">
    /**
     * get params from url
     * @param name
     * @returns {string}
     * @constructor
     */
    function GetRequest(name) {
        var url = location.search;
        var varName = "";
        var varVal = "";
        if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            strs = str.split("&");
            for(var i = 0; i < strs.length; i ++) {
                var temp = strs[i].split("=");
                varName = temp[0];
                if(name == varName){
                    varVal = temp[1];
                }
            }
        }
        return varVal;
    }

    /**
     * show current page
     */
    function showPageNow(){
        var pageNow = GetRequest("pageNow");
        if(pageNow == ""){
            pageNow = "1";
        }
        var id = "jump" + pageNow;
        var aTag = document.getElementById(id);
        aTag.setAttribute("style","background-color: rgba(255,255,255,0.3);")
    }
</script>

<div id="pages">
    <table>
        <tr>
            <td>
                <?php
                showPages();
                ?>
            </td>
            <!--
            <th>ItemPrePage</th>
            <td><input type="number" name="count" id="item-count"
                       min="1" max="10" step="1" value="3"></td>-->
        </tr>
    </table>
</div>
<?php
showBooks();
?>

</body>
</html>