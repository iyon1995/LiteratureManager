<?php

/**
 * Created by PhpStorm.
 * Author: rui.song
 * Date: 12/6/2018
 * Time: 7:47 PM
 * Version:
 * Description:
 */
class Book
{
    private $bookId;
    private $bookName;
    private $author;
    private $status;
    private $comment;
    private $rating;
    private $isSys;

    public function __construct()
    {
        $a=func_get_args();
        $i=func_num_args();
        if(method_exists($this,$f='__construct'.$i)){
            call_user_func_array(array($this,$f),$a);
        }
    }

    /**
     * @param $bookId
     */
    public function __construct1($bookId){
        $this -> bookId = $bookId;
        $this -> bookName = "";
        $this -> author = "";
        $this -> status = "";
        $this -> comment = "";
        $this -> rating = "";
        $this -> isSys = "";
    }

    /**
     * @param $bookId
     * @param $bookName
     * @param $author
     * @param $status
     * @param $rating
     * @param $isSys
     * @param $comment
     */
    public function __construct7($bookId,$bookName,$author,$status,$rating,$isSys,$comment){
        $this -> bookId = $bookId;
        $this -> bookName = $bookName;
        $this -> author = $author;
        $this -> status = $status;
        $this -> comment = $comment;
        $this -> rating = $rating;
        $this -> isSys = $isSys;
    }

    /**
     * @return mixed
     */
    public function getBookId()
    {
        return $this->bookId;
    }

    /**
     * @param mixed $bookId
     */
    public function setBookId($bookId)
    {
        $this->bookId = $bookId;
    }

    /**
     * @return mixed
     */
    public function getBookName()
    {
        return $this->bookName;
    }

    /**
     * @param mixed $bookName
     */
    public function setBookName($bookName)
    {
        $this->bookName = $bookName;
    }

    /**
     * @return mixed
     */
    public function getAuthor()
    {
        return $this->author;
    }

    /**
     * @param mixed $author
     */
    public function setAuthor($author)
    {
        $this->author = $author;
    }

    /**
     * @return mixed
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * @param mixed $status
     */
    public function setStatus($status)
    {
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getComment()
    {
        return $this->comment;
    }

    /**
     * @param mixed $comment
     */
    public function setComment($comment)
    {
        $this->comment = $comment;
    }

    /**
     * @return mixed
     */
    public function getRating()
    {
        return $this->rating;
    }

    /**
     * @param mixed $rating
     */
    public function setRating($rating)
    {
        $this->rating = $rating;
    }

    /**
     * @return mixed
     */
    public function getisSys()
    {
        return $this->isSys;
    }

    /**
     * @param mixed $isSys
     */
    public function setIsSys($isSys)
    {
        $this->isSys = $isSys;
    }


}