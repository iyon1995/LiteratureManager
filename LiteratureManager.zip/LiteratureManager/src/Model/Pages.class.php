<?php

/**
 * Created by PhpStorm.
 * Author: rui.song
 * Date: 12/6/2018
 * Time: 9:28 PM
 * Version:
 * Description:
 */
class Pages
{

    private $pageSize;
    private $rowCount;
    private $pageCount;
    private $startNo;
    private $pageFile;

    /**
     * Pages constructor.
     * a general constructor to call specific constructor according param num
     */
    public function __construct() {
        $a=func_get_args();
        $i=func_num_args();
        if(method_exists($this,$f='__construct'.$i)){
            call_user_func_array(array($this,$f),$a);
        }
    }

    /**
     * @param $rowCount
     * @param $pageSize
     * @param $pageNow
     * @param $pageFile
     */
    public function __construct4($rowCount,$pageSize,$pageNow,$pageFile){
        $this -> rowCount = $rowCount;
        $this -> pageSize = $pageSize;
        $this -> pageFile = $pageFile;
        $this -> pageNow = $pageNow;
        $this -> pageCount = ceil($rowCount / $pageSize);
        $this -> startNo = ($pageNow - 1) * $pageSize;

        //$this -> paging($pageFile,$pageNow);
    }

    /**
     * generate pages
     */
    public function paging(){

        if($this -> pageNow > 1){
            $prePage = $this -> pageNow - 1;
            echo "<a href='" .$this -> pageFile ."?pageNow=$prePage'><u>Prev</u></a>&nbsp";
        }

        for ($i = 1; $i <= $this -> pageCount; $i++) {
            if($this -> pageCount > 10){
                if($i != 1 && $i != $this -> pageCount){
                    if($this -> pageNow <= 6){
                        if($i <= 7){
                            echo "<a href='" .$this -> pageFile ."?pageNow=$i' id='jump" .$i ."'><u>$i</u></a>&nbsp";
                        }else if($i == ($this -> pageCount - 1)){
                            echo "...";
                        }
                    }else if($this -> pageNow > 6 && $this -> pageNow <  ($this -> pageCount - 6)){
                        if($i == 2 || $i == $this -> pageCount - 1){
                            echo "...";
                        }else if($i > ($this -> pageNow - 3) && $i < ($this -> pageNow + 3)){
                            echo "<a href='" .$this -> pageFile ."?pageNow=$i' id='jump" .$i ."'><u>$i</u></a>&nbsp";
                        }
                    }else if($this -> pageNow >=  ($this -> pageCount - 6)){
                        if($i == 2){
                            echo "...";
                        }else if($i > ($this -> pageNow - 3)){
                            echo "<a href='" .$this -> pageFile ."?pageNow=$i' id='jump" .$i ."'><u>$i</u></a>&nbsp";
                        }
                    }
                }else /*if($i == 1 || $i == $pageCount)*/{
                    echo "<a href='" .$this -> pageFile ."?pageNow=$i' id='jump" .$i ."'><u>$i</u></a>&nbsp";
                }
            } else {
                echo "<a href='" .$this -> pageFile ."?pageNow=$i' id='jump" .$i ."'><u>$i</u></a>&nbsp";
            }
        }

        if($this -> pageNow < $this -> pageCount){
            $nextPage = $this -> pageNow + 1;
            echo "<a href='" .$this -> pageFile ."?pageNow=$nextPage'><u>Next</u></a>&nbsp";
        }

        echo "[" .$this -> pageNow ."/" .$this -> pageCount ."]";
        echo "<br/>";
    }

    /**
     * @return mixed
     */
    public function getPageSize()
    {
        return $this->pageSize;
    }

    /**
     * @param mixed $pageSize
     */
    public function setPageSize($pageSize)
    {
        $this->pageSize = $pageSize;
    }

    /**
     * @return mixed
     */
    public function getRowCount()
    {
        return $this->rowCount;
    }

    /**
     * @param mixed $rowCount
     */
    public function setRowCount($rowCount)
    {
        $this->rowCount = $rowCount;
    }

    /**
     * @return mixed
     */
    public function getPageCount()
    {
        return $this->pageCount;
    }

    /**
     * @param mixed $pageCount
     */
    public function setPageCount($pageCount)
    {
        $this->pageCount = $pageCount;
    }

    /**
     * @return mixed
     */
    public function getStartNo()
    {
        return $this->startNo;
    }

    /**
     * @param mixed $startNo
     */
    public function setStartNo($startNo)
    {
        $this->startNo = $startNo;
    }


}