<?php

/**
 * Created by PhpStorm.
 * Author: rui.song
 * Date: 12/6/2018
 * Time: 8:19 PM
 * Version:
 * Description:
 */

require_once '../Dao/DataProcessor.class.php';

class BookService
{
    /**
     * get books in pages
     * @param $startNo
     * @param $pageSize
     * @return mixed
     */
    function getBooks($startNo,$pageSize){
        $dataProcessor = new DataProcessor();
        $sql = "select t.BK_ID,t.BK_NAME,t.AUTHOR,t.STATUS,t.RATING,t.IS_SYS,t.REMARK from T_BOOK_DML t limit ?,?;";
        $books = $dataProcessor -> getBooks($startNo,$pageSize,$sql);
        $dataProcessor -> conn_close();
        /*
        echo "<pre>";
        print_r($books);
        echo "</pre>";
        */
        return $books;
    }

    /**
     * get pages
     * @return mixed
     */
    function getPages(){
        $count_sql = "select count(t.BK_ID) from T_BOOK_DML t;";
        $dataProcessor = new Dataprocessor();
        $res = $dataProcessor -> execute_dql($count_sql);
        if($rowC = $res ->fetch_row()){
            $rowCount = $rowC[0];
        }
        $res -> free();
        $dataProcessor -> conn_close();
        return $rowCount;
    }

    /**
     * create a new book
     * @param $book
     * @return int
     */
    function addBook($book){
        $sql = "insert into T_BOOK_DML(BK_NAME,AUTHOR,STATUS,RATING,IS_SYS,REMARK) values (?,?,?,?,?,?);";
        $dataProcessor = new Dataprocessor();
        $isSucc = $dataProcessor -> addBook($book,$sql);
        $dataProcessor -> conn_close();
        return $isSucc;
    }
}