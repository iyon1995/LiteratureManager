<?php

/**
 * Created by PhpStorm.
 * Author: rui.song
 * Date: 12/6/2018
 * Time: 7:41 PM
 * Version:
 * Description:
 */

require_once '../Model/Book.class.php';


class Dataprocessor
{
    private $conn;
    private $dbName = "lit_test";
    private $host = "localhost";
    private $username = "lit_test";
    private $password = "litopr";

    /**
     * Dataprocessor constructor.
     * initialize the connection
     */
    public function __construct()
    {
        $this -> conn = new Mysqli($this -> host,$this -> username,$this -> password,$this -> dbName);
        if($this  -> conn -> connect_error){
            die("fail to connect".$this -> conn -> connect_error);
        }

        $this -> conn -> query("set names utf8");
    }

    /**
     * get books in pages
     * @param $startNo
     * @param $pageSize
     * @param $sql
     * @return mixed
     */
    public function getBooks($startNo,$pageSize,$sql){

        $sql_stmt = $this -> conn -> prepare($sql);

        $sql_stmt -> bind_param("ii",$startNo,$pageSize);


        $sql_stmt->execute();

        $meta = $sql_stmt->result_metadata();
        while ($field = $meta->fetch_field())
        {
            $params[] = &$row[$field->name];
        }

        call_user_func_array(array($sql_stmt, 'bind_result'), $params);


        $counter = 0;
        while($sql_stmt -> fetch()){
            $i = 0;
            foreach ($row as $key => $val){
                $bookList[$i] = $val;
                $i ++;
            }
            $book = new Book($bookList[0],$bookList[1],$bookList[2],$bookList[3],$bookList[4],$bookList[5],$bookList[6]);
            $bookLst[$counter] = $book;
            $counter ++;
        }
        $sql_stmt->close();

        return $bookLst;

    }

    /**
     * a general function to execute simple query sql
     * @param $sql
     * @return bool|mysqli_result
     */
    public function execute_dql($sql){
        $res = $this -> conn -> query($sql) or die ("sql".$this -> conn -> error);
        return $res;
    }

    /**
     * a function to insert new book
     * @param $book
     * @param $sql
     * @return int
     */
    public function addBook($book,$sql){
        $sql_stmt = $this -> conn -> prepare($sql);

        $title = $book -> getBookName();
        $author = $book -> getAuthor();
        $status = $book -> getStatus();
        $rating = $book -> getRating();
        $comment = $book -> getComment();
        $isSys = $book -> getisSys();

        $sql_stmt -> bind_param("ssssss",$title,$author,$status,$rating,$isSys,$comment);
        $sql_stmt -> execute();

        $isSucc = $sql_stmt -> affected_rows;
        $sql_stmt -> free_result();
        $sql_stmt -> close();
        return $isSucc;
    }

    /**
     * close mysql connection
     */
    public function conn_close(){
        if (!empty($this->conn)) {
            $this -> conn -> close();
        }
    }


}
